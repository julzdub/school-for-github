Names:
==============================
 Ryan Cranston, Petal Michaud, Julian Welge   
 Team 6

Complications
==============================

How to Compile
==============================
Javac lab7/CSCD437Lab7.java
Javac lab7/Team6Member1.java

How to Run
==============================
Java lab7.CSCD437Lab7