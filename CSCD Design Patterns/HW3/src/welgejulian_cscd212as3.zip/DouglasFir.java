public class DouglasFir extends HolidayItem {

    public DouglasFir() {
        super.description = "Douglas Fir";
    }

    public double cost() {
        return 35.0;
    }

    public String description() {
        return description;
    }

}
