public abstract class HolidayItem {
    public boolean hasStar;
    public String description;
    public abstract String description();
    public abstract double cost();

}
