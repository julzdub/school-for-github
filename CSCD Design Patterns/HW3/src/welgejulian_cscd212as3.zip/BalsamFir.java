public class BalsamFir extends HolidayItem {
    public BalsamFir() {
        this.description = "Balsam Fir";
    }

    public double cost() {
        return 35.0;
    }

    public String description() {
        return description;
    }
}
