public abstract class Decorator extends HolidayItem {
    public abstract String description();
    public abstract double cost();
}
