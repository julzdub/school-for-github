public class FraserFir extends HolidayItem {

    public FraserFir() {
        description = "Fraser Fir";
    }

    public double cost() {
        return 35.0;
    }

    public String description() {
        return description;
    }

}
