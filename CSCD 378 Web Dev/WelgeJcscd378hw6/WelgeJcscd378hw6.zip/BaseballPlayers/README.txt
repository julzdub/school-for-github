go to project directory and run php artisan serve
open prompted address in the browser
can create, edit, delete - has success messages for all
currently does not sort by category
pages work 25 per page
can re-seed the database by typing "php artisan db:seed" in command line
hard to tell but player details is within a tile pulled from CSS
