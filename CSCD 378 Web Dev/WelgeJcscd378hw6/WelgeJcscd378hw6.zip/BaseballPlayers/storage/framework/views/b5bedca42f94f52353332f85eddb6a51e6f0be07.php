<?php $__env->startSection('header'); ?>
My Baseball Players App
<h3>Players List</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a class="btn btn-primary" href="<?php echo e(route('baseballplayers.create')); ?>">Add Player</a>
<table class="table table-striped table-hover">
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Team</th>
        <th>Position</th>
        <th>Jersey Number</th>
        <th>Age</th>
        <th></th>
        <th></th>
        <th></th>
    </tr>
    <?php $__currentLoopData = $ballplayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($player->first); ?></td>
        <td><?php echo e($player->last); ?></td>
        <td><?php echo e($player->team); ?></td>
        <td><?php echo e($player->position); ?></td>
        <td><?php echo e($player->jersey_number); ?></td>
        <td><?php echo e($player->age); ?></td>
        <td><a href="<?php echo e(route('baseballplayers.show', $player->id)); ?>">Show Detail</a></td>
        <td><a href="<?php echo e(route('baseballplayers.edit', $player->id)); ?>">Edit</a></td>
        <td>
            <form action="<?php echo e(route('baseballplayers.destroy', $player->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete <?php echo e($player->first); ?>?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-error" type="submit">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($ballplayers->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw6/BaseballPlayers/resources/views/baseballplayers/index.blade.php ENDPATH**/ ?>