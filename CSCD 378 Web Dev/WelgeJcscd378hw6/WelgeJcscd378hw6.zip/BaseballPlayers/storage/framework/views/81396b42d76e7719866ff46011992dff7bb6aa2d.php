<?php $__env->startSection('header'); ?>
Edit Player
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="column col-3">
    <h3>Update Player</h3>
    <?php if($errors->any()): ?>
    <div class="toast toast-error">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span><?php echo e($error); ?></span><br />
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('baseballplayers.update', $ballplayers->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="form-group">
            <label class="form-label" for="first">First Name</label>
            <input class="form-label" type="text" name="first" id="first" value="<?php echo e($ballplayers->first); ?>"></input>

            <label class="form-label" for="last">Last Name</label>
            <input class="form-label" type="text" name="last" id="last" value="<?php echo e($ballplayers->last); ?>"></input>

            <label class="form-label" for="team">Team</label>
            <input class="form-label" type="text" name="team" id="team" value="<?php echo e($ballplayers->team); ?>"></input>

            <label class="form-label" for="jersey_number">Jersey Number</label>
            <input class="form-label" type="text" maxlength="2" name="jersey_number" id="jersey_number" value="<?php echo e($ballplayers->jersey_number); ?>"></input>

            <label class="form-label" for="position">Position</label>
            <select class="form-select" name="position" value="<?php echo e($ballplayers->position); ?>">
                <option value="P">Pitcher</option>
                <option value="C">Catcher</option>
                <option value="1B">First Base</option>
                <option value="2B">Second Base</option>
                <option value="3B">Third Base</option>
                <option value="SS">Short Stop</option>
                <option value="LF">Left Field</option>
                <option value="CF">Center Field</option>
                <option value="RF">Right Field</option>
            </select>

            <label class="form-label" for="age">Age</label>
            <input class="form-label" type="integer" maxlength="3" name="age" id="age" value="<?php echo e($ballplayers->age); ?>"></input>

        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Update Player</button>
            <a href="<?php echo e(route('baseballplayers.index')); ?>">Cancel</a>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw6/BaseballPlayers/resources/views/baseballplayers/edit.blade.php ENDPATH**/ ?>