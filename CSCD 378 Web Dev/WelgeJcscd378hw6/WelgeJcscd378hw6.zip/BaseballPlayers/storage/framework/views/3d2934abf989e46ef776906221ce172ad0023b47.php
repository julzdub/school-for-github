<?php $__env->startSection('header'); ?>
Player
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="tile">
    <div class="tile-content">
        <p class="tile-title">Name: <?php echo e($ballplayers->first); ?> <?php echo e($ballplayers->last); ?></p>
        <p class="tile-subtitle">Team: <?php echo e($ballplayers->team); ?></p>
        <p>Jersey Number: <?php echo e($ballplayers->jersey_number); ?></p>
        <p>Position: <?php echo e($ballplayers->position); ?></p>
        <p>Age: <?php echo e($ballplayers->age); ?></p>
    </div>
</div>

<p>
    <a href="<?php echo e(route('baseballplayers.index')); ?>">Go Back to Baseball Players</a>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw6/BaseballPlayers/resources/views/baseballplayers/show.blade.php ENDPATH**/ ?>