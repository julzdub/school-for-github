<?php return array (
  'playground' => 'App\\Http\\Livewire\\Playground',
);