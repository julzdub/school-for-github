<?php $__env->startSection('header'); ?>
<h1>My Cities App</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
Cities
<?php $__env->stopSection(); ?>

<div>
    <input wire:model="citySearch" type="text" placeholder="Search Cities"/>
    <table class="table table-striped table-hover">
        <tr>
            <th><a href="#" wire:click = "doSort('name', 'asc')">&#8679;</a> City Name <a href="#" wire:click = "doSort('name', 'desc')">&#8681;</a></th>
            <th><a href="#" wire:click = "doSort('state', 'asc')">&#8679;</a> State <a href="#" wire:click = "doSort('state', 'desc')">&#8681;</a></th>
            <th><a href="#" wire:click = "doSort('population_2010', 'asc')">&#8679;</a> 2010 Population <a href="#" wire:click = "doSort('population_2010', 'desc')">&#8681;</a></th>
            <th><a href="#" wire:click = "doSort('population_rank', 'asc')">&#8679;</a> Population Rank <a href="#" wire:click = "doSort('population_rank', 'desc')">&#8681;</a></th>
        </tr>
        <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($city->name); ?></td>
            <td><?php echo e($city->state); ?></td>
            <td><?php echo e($city->population_2010); ?></td>
            <td><?php echo e($city->population_rank); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div><?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw7/CityNameDbApp/resources/views/livewire/playground.blade.php ENDPATH**/ ?>