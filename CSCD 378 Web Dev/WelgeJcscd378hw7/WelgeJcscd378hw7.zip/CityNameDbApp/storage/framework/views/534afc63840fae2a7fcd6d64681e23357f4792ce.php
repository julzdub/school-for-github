<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Livewire Cities</title>
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div class="container m-2">
        <h1><?php echo $__env->yieldContent('title'); ?></h1>
        <div class="mt-1">
            <?php echo e($slot); ?>

        </div>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw7/CityNameDbApp/resources/views/layouts/app.blade.php ENDPATH**/ ?>