<!DOCTYPE html>


<?php $__env->startSection('header'); ?>
City List from DB!
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="table table-striped table-hover">
    <tr>
        <th>City Name</th>
        <th>State</th>
        <th>2010 Population</th>
        <th>Population Rank</th>
    </tr>
    <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($city->name); ?></td>
        <td><?php echo e($city->state); ?></td>
        <td><?php echo e($city->population_2010); ?></td>
        <td><?php echo e($city->population_rank); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

</html>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw7/CityNameDbApp/resources/views/city_list.blade.php ENDPATH**/ ?>