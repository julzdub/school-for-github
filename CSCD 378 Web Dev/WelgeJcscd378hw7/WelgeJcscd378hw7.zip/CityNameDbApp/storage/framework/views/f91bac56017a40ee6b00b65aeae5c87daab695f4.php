<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-exp.min.css">
    <link rel="stylesheet" href="https://unpkg.com/spectre.css/dist/spectre-icons.min.css">
    <div class="hero bg-primary">
        <div class="hero-body">
            <h1> <?php echo $__env->yieldContent('header'); ?></h1>
        </div>
    </div>
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
<?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw7/CityNameDbApp/resources/views/layouts/master.blade.php ENDPATH**/ ?>