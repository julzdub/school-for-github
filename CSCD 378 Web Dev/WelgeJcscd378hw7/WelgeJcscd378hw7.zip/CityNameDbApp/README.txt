inside this 'citynamedbapp' directory, run: php artisan serve
go to the specified IP address and the project will load on the home page
should be something like: http://127.0.0.1:8000/
the vender directory is included, im sorry if it takes a minute to load, peace and love <3