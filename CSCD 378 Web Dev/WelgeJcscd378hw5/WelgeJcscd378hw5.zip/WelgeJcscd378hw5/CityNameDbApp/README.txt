inside this 'citynamedbapp' directory, run: php artisan serve
go to the specified IP address and go to the: /cities/ page
should be something like: http://127.0.0.1:8000/cities/