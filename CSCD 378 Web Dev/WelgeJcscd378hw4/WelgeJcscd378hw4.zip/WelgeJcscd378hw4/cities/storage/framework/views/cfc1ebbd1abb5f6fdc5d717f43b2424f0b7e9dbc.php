<html>

<head>
    <title>
        Cities & Population!
    </title>
</head>

<body>

    <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($city); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html><?php /**PATH /Users/julian/Desktop/CSCD 378 Web Dev/WelgeJcscd378hw4/cities/resources/views/cities/index.blade.php ENDPATH**/ ?>