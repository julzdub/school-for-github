<html>

<head>
    <title>
        Cities & Population!
    </title>
</head>

<body>

    @foreach($places as $city)
        <p>{{$city}}</p>
    @endforeach

</body>

</html>